//
//  PlaySoundsViewController.swift
//  Pitch Perfect
//
//  Created by Malak Sadik on 28/10/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController {
    //control-drag from button to the code or write the IBOutlet as bellow. Then, from the document outline, control-drag from the view controller to each butoon to connect
    @IBOutlet weak var snailButton: UIButton!
    @IBOutlet weak var chipmunkButton: UIButton!
    @IBOutlet weak var rabbitButton: UIButton!
    @IBOutlet weak var vaderButton: UIButton!
    @IBOutlet weak var echoButton: UIButton!
    @IBOutlet weak var reverbButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    
    var recordedAudioURL:URL!
    var audioFile:AVAudioFile!
    var audioEngine:AVAudioEngine!
    var audioPlayerNode: AVAudioPlayerNode!
    var stopTimer: Timer!
    
    enum ButtonType: Int {
        case slow = 0, fast, chipmunk, vader, echo, reverb
    }
    
    //create two functions: one for the six  audio buttons and 1 for the stop buttons. Then, from the document outline, control-drag from the button to the view controller
    @IBAction func playSoundForButton (_ sender: UIButton) {
        print ("play sound button pressed")
        switch(ButtonType(rawValue: sender.tag)!) {//make sure to set unique tags for each button
        case .slow://mapped to 0 (enum)
            playSound(rate: 0.5)
        case .fast:
            playSound(rate: 1.5)
        case .chipmunk:
            playSound(pitch: 1000)
        case .vader:
            playSound(pitch: -1000)
        case .echo:
            playSound(echo: true)
        case .reverb:
            playSound(reverb: true)
        }
        
        configureUI(.playing)
        
    }
    
    @IBAction func stopButtonPressed (_ sender: AnyObject) {
        print ("stop audio button pressed")
        stopAudio()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        setupAudio()//a function from the extension
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super .viewWillAppear(animated)
        configureUI(.notPlaying)//a function from the extension
    }


}
