//
//  RecordSoundsViewController.swift
//  Pitch Perfect
//
//  Created by Malak Sadik on 19/01/2018.
//  Copyright © 2018 Malak Sadik. All rights reserved.
//

import UIKit
import AVFoundation //contains athe avAudio

class RecordSoundsViewController: UIViewController, AVAudioRecorderDelegate {//class conforms to the AVAudioRecorderDelegate protocol. a delegate relationship, one entity gets another to do some work for them, and the second entity can notify the first when the work is done.

    @IBOutlet weak var recordLabel: UILabel!
    
    @IBOutlet weak var recordButton: UIButton!
    
    @IBOutlet weak var stopRecordingButton: UIButton!
    
    var audioRecorder: AVAudioRecorder!//reference audio recording in different funcs

    @IBAction func RecordAudio(_ sender: Any) {
        print("Record button is pressed")
        configRecording(true)
        
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String //document directory as a string
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath = URL(string: pathArray.joined(separator: "/"))//full path of the recorded audio file
        print(filePath!)
        
        let session = AVAudioSession.sharedInstance()//shared Av audio session across all apps on a devis
        try! session.setCategory(AVAudioSessionCategoryPlayAndRecord, with:AVAudioSessionCategoryOptions.defaultToSpeaker)
        
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        audioRecorder.delegate = self//set this viewController as delegate to the audioRecorder
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecording(_ sender: Any) {
        print("stop Recording button is pressed")
        configRecording(false)
        
        audioRecorder.stop()
        let session = AVAudioSession.sharedInstance()
        try! session.setActive(false)
    }
    
    func configRecording (_ recording : Bool) {
        
        recordLabel.text = recording ? "Recording in progress" : "Tap to record"
        stopRecordingButton.isEnabled = recording
        recordButton.isEnabled = !recording
        
    }
    
    // MARK: - Audio Recorder Delegate
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        print("Finish recording..")
        if flag {// successfully saved
           performSegue(withIdentifier: "stopRecording", sender: audioRecorder.url)
        } else {
            print("Recording was not successful")
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "stopRecording" {
            let playSoundsVC = segue.destination as! PlaySoundsViewController //the destination viewController (sing forced upcast)
            let recordedAudioURL = sender as! URL // as the sender in performinSegue is audioRecorder.url
            playSoundsVC.recordedAudioURL = recordedAudioURL // set the recordedAudioURL to recordingAudioUrl which is a property in PlaySoundsViewController class
        }
    }
    
}

